# 该功能已经在core/bzsh/core_other.bzsh中实现
# test -e "${HOME}/.iterm2_shell_integration.zsh" && source "${HOME}/.iterm2_shell_integration.zsh"